Check what port your Arduino Mega 2560 is connected to by pressing the "windows key + x" and select "Device Manager".
Expand the "Ports (COM & LPT)"-tab and look for something similar to "USB-SERIAL CH340 (COM3)".
Remember the COM number (in this case 3) and proceed either with:

1. Automatic method:
	- Run "UPLOAD_automatically.exe"
	- Enter your port number
	- Wait for upload of code
	- Done

2. Manual method:
	- Type "cmd" in the XXX and press enter
	- The command window should open with the path set to your "ArduinoSketchUploader-3.0.0"-folder
	- In cmd, enter: 
		ArduinoSketchUploader.exe --file=Gene_automation.hex --port=COM3 --model=Mega2560
	- Make sure all paths and the port are correct
	- Start the upload by pressing enter
	- Wait for it to finish
	- Done
	
If for some reason you get an error "|WARN|ArduinoSketchUploader|STK500V2 wrapper corrupted (No Start Message detected!)!",
try to set a different COM-port, hit enter, then the process will fail, set the COM-port correct again -> now it should work again.